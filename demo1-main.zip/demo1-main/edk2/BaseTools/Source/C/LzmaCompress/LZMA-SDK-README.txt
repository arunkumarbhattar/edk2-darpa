LzmaCompress is based on the LZMA SDK 19.00.  LZMA SDK 19.00
was placed in the public domain on 2019-02-21.  It was
released on the http://www.7-zip.org/sdk.html website.
