#ifndef __PCCTS_STDIO_H__
#define __PCCTS_STDIO_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <cstdio>
#else
#include <stdio.h>
#endif

#endif
